import { useMemo, useState } from "react";
import logo from "./assets/chapimo-logo.jpeg";

const listings = [
  {
    id: "L-001",
    title: "Appartement moderne a louer",
    type: "Location",
    price: "850 $ / mois",
    city: "Kinshasa",
    commune: "Gombe",
    district: "Socimat",
    bedrooms: 2,
    baths: 2,
    agency: "Immo Plus RDC",
    image:
      "https://images.unsplash.com/photo-1493809842364-78817add7ffb?auto=format&fit=crop&w=900&q=80",
    featured: true,
  },
  {
    id: "L-002",
    title: "Maison familiale avec parcelle",
    type: "Vente",
    price: "145 000 $",
    city: "Kinshasa",
    commune: "Ngaliema",
    district: "Joli Parc",
    bedrooms: 4,
    baths: 3,
    agency: "Congo Habitat",
    image:
      "https://images.unsplash.com/photo-1564013799919-ab600027ffc6?auto=format&fit=crop&w=900&q=80",
    featured: false,
  },
  {
    id: "L-003",
    title: "Studio meuble proche boulevard",
    type: "Location",
    price: "420 $ / mois",
    city: "Kinshasa",
    commune: "Kasa-Vubu",
    district: "ONATRA",
    bedrooms: 1,
    baths: 1,
    agency: "Agence Mboka",
    image:
      "https://images.unsplash.com/photo-1505693416388-ac5ce068fe85?auto=format&fit=crop&w=900&q=80",
    featured: false,
  },
];

const initialLeads = [
  {
    id: "D-104",
    listingId: "L-001",
    client: "Patrick M.",
    whatsapp: "+243 899 124 450",
    status: "locked",
    createdAt: "Aujourd'hui, 10:22",
  },
  {
    id: "D-103",
    listingId: "L-002",
    client: "Grace N.",
    whatsapp: "+243 817 765 118",
    status: "unlocked",
    createdAt: "Hier, 16:08",
  },
];

function maskPhone(phone) {
  return phone.replace(/(\+\d{3})\s?(\d{2})\d+\s?(\d{3})$/, "$1 $2* *** $3");
}

function Icon({ label }) {
  return <span className="icon" aria-hidden="true">{label}</span>;
}

function App() {
  const [view, setView] = useState("client");
  const [filters, setFilters] = useState({ city: "Toutes", commune: "Toutes", district: "Tous" });
  const [selectedListing, setSelectedListing] = useState(listings[0]);
  const [leads, setLeads] = useState(initialLeads);

  const options = useMemo(() => {
    const unique = (key) => ["Toutes", ...new Set(listings.map((item) => item[key]))];
    return {
      city: unique("city"),
      commune: unique("commune"),
      district: ["Tous", ...new Set(listings.map((item) => item.district))],
    };
  }, []);

  const filteredListings = listings.filter((item) => {
    return (
      (filters.city === "Toutes" || item.city === filters.city) &&
      (filters.commune === "Toutes" || item.commune === filters.commune) &&
      (filters.district === "Tous" || item.district === filters.district)
    );
  });

  const requestLead = () => {
    const lead = {
      id: `D-${Math.floor(200 + Math.random() * 700)}`,
      listingId: selectedListing.id,
      client: "Nouveau client",
      whatsapp: "+243 800 000 000",
      status: "locked",
      createdAt: "A l'instant",
    };
    setLeads([lead, ...leads]);
    setView("agency");
  };

  const unlockLead = (id) => {
    setLeads((items) =>
      items.map((lead) => (lead.id === id ? { ...lead, status: "unlocked" } : lead))
    );
  };

  return (
    <main className="app-shell">
      <header className="topbar">
        <div className="brand">
          <img src={logo} alt="Chapimo" />
          <div>
            <strong><span>Chap</span><em>imo</em></strong>
            <small>Clients qualifies pour agences immobilieres</small>
          </div>
        </div>

        <nav className="tabs" aria-label="Navigation principale">
          <button className={view === "client" ? "active" : ""} onClick={() => setView("client")}>
            <Icon label="M" /> Client
          </button>
          <button className={view === "agency" ? "active" : ""} onClick={() => setView("agency")}>
            <Icon label="A" /> Agence
          </button>
          <button className={view === "admin" ? "active" : ""} onClick={() => setView("admin")}>
            <Icon label="C" /> Admin
          </button>
        </nav>
      </header>

      {view === "client" && (
        <section className="client-layout">
          <div className="search-panel">
            <div className="intro">
              <p>Chapimo met en relation les clients et les agences immobilieres verifiees.</p>
              <h1>Trouvez un logement par commune, ville et quartier.</h1>
            </div>

            <div className="filters">
              <Select label="Ville" value={filters.city} values={options.city} onChange={(city) => setFilters({ ...filters, city })} />
              <Select label="Commune" value={filters.commune} values={options.commune} onChange={(commune) => setFilters({ ...filters, commune })} />
              <Select label="Quartier" value={filters.district} values={options.district} onChange={(district) => setFilters({ ...filters, district })} />
            </div>

            <div className="listings">
              {filteredListings.map((listing) => (
                <button
                  key={listing.id}
                  className={`listing-card ${selectedListing.id === listing.id ? "selected" : ""}`}
                  onClick={() => setSelectedListing(listing)}
                >
                  <img src={listing.image} alt="" />
                  <span>{listing.type}</span>
                  <strong>{listing.title}</strong>
                  <small><Icon label="L" /> {listing.commune}, {listing.district}</small>
                  <b>{listing.price}</b>
                </button>
              ))}
            </div>
          </div>

          <aside className="detail-panel">
            <img className="hero-photo" src={selectedListing.image} alt="" />
            <div className="detail-content">
              <div className="badge-row">
                <span>{selectedListing.type}</span>
                {selectedListing.featured && <span className="gold">Annonce verifiee</span>}
              </div>
              <h2>{selectedListing.title}</h2>
              <p className="location"><Icon label="L" /> {selectedListing.city}, {selectedListing.commune}, {selectedListing.district}</p>
              <div className="stats">
                <span><Icon label="B" /> {selectedListing.bedrooms} chambres</span>
                <span><Icon label="D" /> {selectedListing.baths} douches</span>
                <span><Icon label="V" /> Contact protege</span>
              </div>
              <div className="agency-line">
                <Icon label="P" />
                Publie par <strong>{selectedListing.agency}</strong>
              </div>
              <div className="price-line">{selectedListing.price}</div>
              <button className="primary-action" onClick={requestLead}>
                <Icon label="W" /> Je veux ce logement
              </button>
            </div>
          </aside>
        </section>
      )}

      {view === "agency" && (
        <section className="workspace">
          <PanelTitle eyebrow="Espace agence" title="Demandes recues" text="Les contacts clients restent masques jusqu'au deblocage par Chapimo." />
          <div className="lead-grid">
            {leads.map((lead) => {
              const listing = listings.find((item) => item.id === lead.listingId);
              return (
                <article className="lead-card" key={lead.id}>
                  <div>
                    <span className={lead.status === "unlocked" ? "status open" : "status"}>
                      {lead.status === "unlocked" ? <Icon label="O" /> : <Icon label="F" />}
                      {lead.status === "unlocked" ? "Debloque" : "Verrouille"}
                    </span>
                    <h3>{lead.client}</h3>
                    <p>{listing?.title}</p>
                  </div>
                  <strong>{lead.status === "unlocked" ? lead.whatsapp : maskPhone(lead.whatsapp)}</strong>
                  <small>{lead.createdAt}</small>
                  <button disabled={lead.status !== "unlocked"}>
                    <Icon label="W" /> Contacter sur WhatsApp
                  </button>
                </article>
              );
            })}
          </div>
        </section>
      )}

      {view === "admin" && (
        <section className="workspace">
          <PanelTitle eyebrow="Admin Chapimo" title="Deblocage manuel des contacts" text="Cette version prepare le futur paiement forfaitaire, sans l'activer pour le debut." />
          <div className="admin-table">
            {leads.map((lead) => {
              const listing = listings.find((item) => item.id === lead.listingId);
              return (
                <div className="admin-row" key={lead.id}>
                  <div>
                    <strong>{lead.client}</strong>
                    <small>{listing?.agency} - {listing?.title}</small>
                  </div>
                  <span>{lead.status === "unlocked" ? "Contact visible" : "Contact masque"}</span>
                  <button onClick={() => unlockLead(lead.id)} disabled={lead.status === "unlocked"}>
                    <Icon label="OK" /> Debloquer
                  </button>
                </div>
              );
            })}
          </div>
        </section>
      )}
    </main>
  );
}

function Select({ label, value, values, onChange }) {
  return (
    <label>
      <span>{label}</span>
      <select value={value} onChange={(event) => onChange(event.target.value)}>
        {values.map((item) => (
          <option key={item} value={item}>{item}</option>
        ))}
      </select>
    </label>
  );
}

function PanelTitle({ eyebrow, title, text }) {
  return (
    <div className="panel-title">
      <span>{eyebrow}</span>
      <h1>{title}</h1>
      <p>{text}</p>
    </div>
  );
}

export default App;
