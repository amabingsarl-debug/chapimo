# OpenAI Build Week - Submission Pack

Use this file to fill Devpost. Replace each `YOUTUBE_DEMO_LINK_HERE` with the final public YouTube demo link.

## 1. Chapimo

Category: Apps for Your Life

Project title: Chapimo

Tagline: Find a home in Abidjan by sending one request to trusted real estate agencies.

Demo link: https://chapimo.com

YouTube demo: YOUTUBE_DEMO_LINK_HERE

Short description:
Chapimo helps people looking for housing in Abidjan submit a clear rental request and receive matching proposals from real estate agencies.

Long description:
Finding a rental home in Abidjan is often slow, fragmented, and stressful. People search across scattered listings, WhatsApp groups, informal contacts, and agencies without knowing who can really help. Chapimo solves this by creating a simple two-sided experience between renters and real estate agencies.

On the client side, a user chooses the type of home, commune, neighborhood, and budget range. If the available listings do not fit, the user can send a housing request to agencies in Abidjan. The request is saved under "My Home" and becomes visible to agencies.

On the agency side, verified agencies can see active client requests, filter by commune, publish listings, and propose homes to clients. A proposal can include rent and up to six photos. The client receives the proposal and can review it before deciding to contact the agency.

Chapimo is built first for Abidjan, with a focus on local communes and neighborhoods. The long-term business model is to let agencies pay a fixed fee to unlock high-intent client contacts, while keeping the client experience simple.

What it does:
- Lets clients search by property type, commune, neighborhood, and budget.
- Lets clients send an active housing request if no listing fits.
- Lets agencies view client requests and propose matching homes.
- Lets agencies publish housing listings.
- Tracks visits, unique devices, app installs, and notification activation.
- Includes an admin space to validate agency collaborators.

How Codex/GPT-5.6 was used:
Codex was used as a full development partner to design, implement, debug, and deploy the application. It helped build the client flow, agency flow, admin validation, Firebase hosting, PWA behavior, notifications, image handling, request/listing storage, mobile UI refinements, and analytics counters. GPT-5.6/Codex also helped refine the product wording, UX decisions, and submission material.

Suggested video script:
1. Start with the problem: finding a home in Abidjan is difficult and scattered.
2. Show the Chapimo home page and housing listings.
3. Show the client search flow: property type, commune, neighborhood, budget.
4. Show the final option to send a request to agencies.
5. Show "My Home" with the saved request.
6. Switch to agency mode and show client requests.
7. Show an agency proposing a home with photos and rent.
8. Show the admin space validating agencies and the statistics counters.
9. End with: Chapimo was built with Codex as a real AI development partner.

Repository link: REPOSITORY_LINK_HERE

README note:
This is a Firebase-hosted PWA. The live demo is available at https://chapimo.com.

## 2. Kufanyi

Category: Work & Productivity

Project title: Kufanyi

Tagline: A productivity platform connecting Chinese companies with interpreters and local talent in Africa.

Demo link: PROJECT_DEMO_LINK_HERE

YouTube demo: YOUTUBE_DEMO_LINK_HERE

Short description:
Kufanyi helps companies publish needs and connect with interpreters or candidates who can help them work faster across language and cultural barriers.

Long description:
Kufanyi is designed for a real business challenge in Africa: many Chinese companies need local interpreters, translators, assistants, and reliable workers, while many local professionals need better access to these opportunities.

The app creates a structured workflow where companies can publish announcements and interested interpreters or candidates can respond. It helps replace scattered WhatsApp conversations with a clearer professional interface for posting needs, viewing candidates, and managing responses.

The project focuses on speed, simplicity, and mobile-first usage. Companies can quickly publish a need, while interpreters can discover relevant opportunities and apply.

What it does:
- Lets companies publish work needs.
- Lets interpreters or candidates view and respond to announcements.
- Organizes applications and candidate interest.
- Supports a mobile-first workflow for daily business use.

How Codex/GPT-5.6 was used:
Codex was used to design and refine the user interface, improve the announcement flow, debug mobile layout issues, and prepare a cleaner product experience for business users. GPT-5.6/Codex also helped define the product positioning and submission story.

Suggested video script:
1. Explain the language and coordination problem between Chinese companies and local workers.
2. Show the announcement list.
3. Show how a company publishes a need.
4. Show how candidates/interpreters respond.
5. Show how Kufanyi makes business coordination clearer and faster.
6. End with Codex helping build and refine the product.

Repository link: REPOSITORY_LINK_HERE

## 3. AmenTok

Category: Education

Project title: AmenTok

Tagline: A learning and communication app designed to make language practice more natural and accessible.

Demo link: PROJECT_DEMO_LINK_HERE

YouTube demo: YOUTUBE_DEMO_LINK_HERE

Short description:
AmenTok helps users practice communication and learning through a simple mobile-first experience.

Long description:
AmenTok is positioned as an education-focused app for people who want to improve communication, language practice, or guided learning in a more accessible way. The goal is to make learning feel less formal and more connected to daily usage.

The app can be presented as a bridge between short-form digital habits and practical learning. Instead of forcing users into heavy courses, AmenTok focuses on a simple experience that can help learners practice, repeat, and progress step by step.

What it does:
- Helps users learn or practice communication.
- Provides a simple mobile-first learning flow.
- Can support language practice, short lessons, or guided interactions.

How Codex/GPT-5.6 was used:
Codex was used to clarify the product structure, improve the user flow, and prepare the submission story. GPT-5.6/Codex helped turn the initial idea into a clearer learning product narrative.

Suggested video script:
1. Explain the learning problem AmenTok solves.
2. Show the first screen and main user flow.
3. Show how a user practices or learns.
4. Explain why the experience is simple and mobile-friendly.
5. End with how Codex helped shape the project.

Repository link: REPOSITORY_LINK_HERE

## 4. HSKMax

Category: Education

Project title: HSKMax

Tagline: A focused learning app for mastering Chinese and preparing for HSK exams.

Demo link: PROJECT_DEMO_LINK_HERE

YouTube demo: YOUTUBE_DEMO_LINK_HERE

Short description:
HSKMax helps learners study Chinese vocabulary, grammar, and exam practice for the HSK levels.

Long description:
HSKMax is an education app for students learning Chinese and preparing for HSK exams. Many learners struggle with vocabulary retention, level progression, listening, reading, and exam-style practice. HSKMax is designed to make that path clearer and more structured.

The app can guide learners by level, help them revise vocabulary, practice sentences, and track progress. The goal is to make Chinese learning more accessible for students who need a focused tool instead of scattered materials.

What it does:
- Helps learners prepare for HSK exams.
- Organizes learning by level.
- Supports vocabulary and practice exercises.
- Helps students track progress over time.

How Codex/GPT-5.6 was used:
Codex was used to structure the learning flow, prepare the interface logic, and refine the product description. GPT-5.6/Codex helped create a clearer education-focused submission around Chinese learning and HSK exam preparation.

Suggested video script:
1. Explain what HSK is and why learners need structure.
2. Show HSKMax levels or learning dashboard.
3. Show vocabulary/practice flow.
4. Show progress or revision.
5. End with how Codex helped build and refine the learning experience.

Repository link: REPOSITORY_LINK_HERE

## 5. Djinzin

Category: Apps for Your Life

Project title: Djinzin

Tagline: Stay connected to your devices and recover them faster when they are lost.

Demo link: PROJECT_DEMO_LINK_HERE

YouTube demo: YOUTUBE_DEMO_LINK_HERE

Short description:
Djinzin helps users stay linked to their devices, communicate with a lost device, and trigger useful remote actions.

Long description:
Djinzin is a personal device companion built for people who need a simple way to stay connected to their phones and other devices. When a device is lost, forgotten, borrowed, or difficult to access, the user needs more than a map. They need a practical way to communicate with the device and request actions remotely.

The product is inspired by real-world situations where people rely on phones, WhatsApp, SMS, shared devices, unstable connectivity, and trusted contacts. Djinzin aims to provide a recovery and remote-action layer that feels simple enough for daily life.

What it does:
- Links a user to their devices.
- Helps locate or recover a lost device.
- Lets the user communicate with a device remotely.
- Can trigger remote actions depending on device permissions and setup.

How Codex/GPT-5.6 was used:
Codex was used to clarify the product positioning, compare existing device recovery tools, and define a stronger Africa-focused use case. GPT-5.6/Codex helped shape the project into a practical life app rather than just another "find my phone" clone.

Suggested video script:
1. Start with the problem: losing a phone is not just about location, it is about control and communication.
2. Show linked devices.
3. Show a lost-device scenario.
4. Show remote communication or remote task request.
5. Explain how Djinzin is designed for real-life device recovery.
6. End with Codex helping define and build the product.

Repository link: REPOSITORY_LINK_HERE

## 6. OlinckBotAI

Category: Developer Tools

Project title: OlinckBotAI

Tagline: An AI bot platform for creating, managing, and automating intelligent assistants.

Demo link: PROJECT_DEMO_LINK_HERE

YouTube demo: YOUTUBE_DEMO_LINK_HERE

Short description:
OlinckBotAI helps users create and manage AI-powered bots that can automate tasks and support digital products.

Long description:
OlinckBotAI is an AI bot platform designed to help people create, manage, and deploy intelligent assistants for different products and workflows. Instead of building every assistant from scratch, users can use OlinckBotAI as a central layer for bot behavior, automation, and service interaction.

For the OpenAI Build Week submission, OlinckBotAI can be presented as a developer and automation tool: a system that helps builders create AI assistants that connect to real product needs, handle tasks, and support users.

What it does:
- Helps create AI-powered bots.
- Supports automation and assistant workflows.
- Can be connected to multiple products.
- Provides a foundation for AI-driven user support or task execution.

How Codex/GPT-5.6 was used:
Codex was used to refine the developer-tool positioning, clarify the bot platform structure, and prepare submission material. GPT-5.6/Codex helped frame OlinckBotAI as a reusable AI assistant infrastructure rather than a single-purpose chatbot.

Suggested video script:
1. Explain the problem: many products need AI assistants, but building each one manually is slow.
2. Show OlinckBotAI dashboard or bot flow.
3. Show how a bot is created or configured.
4. Show an automation or response example.
5. Explain why this helps builders move faster.
6. End with Codex helping design and refine the platform.

Repository link: REPOSITORY_LINK_HERE

## Final Checklist For Each Devpost Submission

- Project title
- Category
- Tagline
- Short description
- Long description
- Demo link
- Public YouTube video under 3 minutes
- Repository link
- README/setup instructions
- Explanation of how Codex/GPT-5.6 was used
- Codex feedback/session ID if requested by Devpost
- Screenshots

