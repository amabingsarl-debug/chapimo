const CACHE_NAME = "chapimo-v183";
const APP_SHELL = ["/", "/chapimo-logo.jpeg", "/notification-badge-v2.png", "/manifest.webmanifest", "/agencies.json"];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(APP_SHELL))
  );
  self.skipWaiting();
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((key) => key !== CACHE_NAME).map((key) => caches.delete(key)))
    )
  );
  self.clients.claim();
});

self.addEventListener("fetch", (event) => {
  if (event.request.method !== "GET") {
    return;
  }

  event.respondWith(
    fetch(event.request)
      .then((response) => {
        const copy = response.clone();
        caches.open(CACHE_NAME).then((cache) => cache.put(event.request, copy));
        return response;
      })
      .catch(() => caches.match(event.request).then((cached) => cached || caches.match("/")))
  );
});

self.addEventListener("push", (event) => {
  let payload = {};
  try {
    payload = event.data ? event.data.json() : {};
  } catch (error) {
    payload = { notification: { body: event.data ? event.data.text() : "" } };
  }
  const notification = payload.notification || {};
  const data = payload.data || {};
  const title = notification.title || data.title || "Chapimo";
  const body = notification.body || data.body || "Nouvelle activite sur Chapimo";
  const url = data.url || payload.fcmOptions?.link || "/";

  event.waitUntil((async () => {
    if (self.registration.setAppBadge) {
      await self.registration.setAppBadge(1).catch(() => {});
    }
    await self.registration.showNotification(title, {
      body,
      icon: notification.icon || "/chapimo-logo.jpeg?v=2",
      badge: "/notification-badge-v2.png",
      tag: data.tag || payload.messageId || "chapimo-push",
      requireInteraction: false,
      data: { url }
    });
  })());
});

self.addEventListener("notificationclick", (event) => {
  event.notification.close();
  if (self.registration.clearAppBadge) {
    self.registration.clearAppBadge().catch(() => {});
  }
  const targetUrl = new URL(event.notification.data && event.notification.data.url ? event.notification.data.url : "/", self.location.origin).href;
  event.waitUntil(
    clients.matchAll({ type: "window", includeUncontrolled: true }).then((clientList) => {
      for (const client of clientList) {
        if ("focus" in client) return client.focus();
      }
      if (clients.openWindow) return clients.openWindow(targetUrl);
      return null;
    })
  );
});
