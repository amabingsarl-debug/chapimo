import admin from "firebase-admin";
import { onDocumentCreated } from "firebase-functions/v2/firestore";

admin.initializeApp();

const db = admin.firestore();

function uniqueTokens(docs) {
  return Array.from(new Set(
    docs
      .map((doc) => doc.get("token"))
      .filter((token) => typeof token === "string" && token.length > 20)
  ));
}

async function sendToTokens(tokens, title, body, data = {}) {
  if (!tokens.length) {
    console.log("No push token target", { title, data });
    return;
  }
  const response = await admin.messaging().sendEachForMulticast({
    tokens,
    notification: {
      title,
      body
    },
    webpush: {
      notification: {
        title,
        body,
        icon: "https://chapimo.com/chapimo-logo.jpeg?v=2",
        badge: "https://chapimo.com/notification-badge-v2.png"
      },
      fcmOptions: {
        link: "https://chapimo.com/"
      }
    },
    data: Object.fromEntries(
      Object.entries(data).map(([key, value]) => [key, String(value ?? "")])
    )
  });
  console.log("Push send result", {
    title,
    targetCount: tokens.length,
    successCount: response.successCount,
    failureCount: response.failureCount,
    errors: response.responses
      .map((item, index) => item.success ? null : {
        index,
        code: item.error?.code || "",
        message: item.error?.message || ""
      })
      .filter(Boolean)
  });
}

export const notifyAgenciesOnRequest = onDocumentCreated(
  {
    document: "chapimoRequests/{requestId}",
    region: "europe-west1"
  },
  async (event) => {
    const request = event.data?.data();
    if (!request) return;

    const commune = request.commune || "";
    const requesterDeviceId = request.ownerDeviceId || "";
    const snapshot = await db.collection("chapimoPushTokens")
      .where("profile", "==", "agency")
      .get();

    const targets = snapshot.docs.filter((doc) => {
      if (doc.id === requesterDeviceId) return false;
      const communes = doc.get("demandCommunes");
      return !Array.isArray(communes) || communes.length === 0 || communes.includes(commune);
    });
    console.log("Request notification targets", {
      requestId: event.params.requestId,
      commune,
      agencyTokens: snapshot.size,
      matchingTargets: targets.length
    });

    await sendToTokens(
      uniqueTokens(targets),
      "Nouvelle demande client",
      `${request.property || "Logement"} - ${commune}${request.quartier ? `, ${request.quartier}` : ""}`,
      {
        type: "request",
        requestId: event.params.requestId
      }
    );
  }
);

export const notifyClientOnProposal = onDocumentCreated(
  {
    document: "chapimoProposals/{proposalId}",
    region: "europe-west1"
  },
  async (event) => {
    const proposal = event.data?.data();
    if (!proposal || !proposal.requestId) return;

    const requestDoc = await db.collection("chapimoRequests").doc(String(proposal.requestId)).get();
    if (!requestDoc.exists) return;

    const clientDeviceId = requestDoc.get("ownerDeviceId");
    if (!clientDeviceId) return;

    const tokenDoc = await db.collection("chapimoPushTokens").doc(String(clientDeviceId)).get();
    if (!tokenDoc.exists) {
      console.log("No client push token", {
        proposalId: event.params.proposalId,
        requestId: proposal.requestId,
        clientDeviceId
      });
      return;
    }
    console.log("Proposal notification target", {
      proposalId: event.params.proposalId,
      requestId: proposal.requestId,
      clientDeviceId
    });

    await sendToTokens(
      uniqueTokens([tokenDoc]),
      "Nouvelle proposition",
      `${proposal.agencyName || "Une agence"} propose ${proposal.property || "un logement"}`,
      {
        type: "proposal",
        proposalId: event.params.proposalId,
        requestId: proposal.requestId
      }
    );
  }
);
